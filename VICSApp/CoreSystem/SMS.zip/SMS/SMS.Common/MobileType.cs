namespace SMS.Common
{
    public enum MobileType
    {
        Viettel,
        Mobiphone,
        Vinaphone,
        Vietnammobile,
        Gmobile,
        SFone,
        Evn,
        None,
    }
}