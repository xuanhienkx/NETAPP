using System;
using System.Collections.Generic;
using System.Configuration;

namespace SMS.Common.Configuration
{
}