using System;
using SMS.Common.Models;

namespace SMS.Common.Action
{
    public delegate SmsResultModel ResultSmsSend(object sender, EventArgs e);
}