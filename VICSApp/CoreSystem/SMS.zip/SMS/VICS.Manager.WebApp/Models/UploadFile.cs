﻿namespace VICS.Manager.WebApp.Models
{
    public class UploadFile
    {
        public string FilePath { get; set; } 
    }
}