﻿namespace SMS.DataAccess.Models
{
    public enum SmsType : short
    {
        All = 0,
        KhopLenh = 1,
        DauNgay,
        ThongBao,
        DatLenh,
        Normal,
        NopRut

    }
}