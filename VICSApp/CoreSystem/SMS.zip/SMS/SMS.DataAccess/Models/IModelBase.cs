﻿namespace SMS.DataAccess.Models
{
    public interface IModelBase
    {
    }
}