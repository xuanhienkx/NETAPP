﻿namespace SMS.Data.Services.EF.Models
{ 
    public class SecurityModel
    {
        public string AccountId { get; set; }
        public string StockCode { get; set; }
        public long Quantity { get; set; }
    }
}