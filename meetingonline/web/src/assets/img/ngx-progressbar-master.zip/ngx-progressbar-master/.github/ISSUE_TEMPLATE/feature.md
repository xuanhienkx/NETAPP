---
name: Feature
about: Propose a new feature for ngx-progressbar
labels: feature
---
 
#### Feature Description

Provide a brief summary of the feature you would like to see.

#### Use Case

Describe the use case(s) that the proposed feature would enable.
