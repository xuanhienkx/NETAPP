---
name: Documentation
about: Suggest an improvement to our documentation at https://github.com/MurhafSousli/ngx-progressbar/wiki
labels: docs
---

#### Documentation Feedback

Provide a brief summary of what you would like to see changed in our 
documentation at https://github.com/MurhafSousli/ngx-progressbar/wiki.

Feel free to provide any suggestions of content or examples you’d like us to include.
